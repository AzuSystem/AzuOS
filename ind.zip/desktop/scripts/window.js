function newWindow(title) {
	console.log('Not implemented')
}